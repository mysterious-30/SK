#!/bin/bash

# Setup script for Continuous SK Finder
# This will install dependencies and set up the environment on a Linux VPS

echo "======================================"
echo "  Continuous SK Finder Setup Script"
echo "======================================"
echo

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed."
    echo "Since you don't have root access, you'll need to ask your VPS provider to install Python 3."
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 --version | cut -d " " -f 2)
echo "Python version: $PYTHON_VERSION"

# Create virtual environment (works without root)
echo "Creating Python virtual environment..."
python3 -m venv sk_env 2>/dev/null

# If venv module is not available, try to continue without it
if [ $? -ne 0 ]; then
    echo "Could not create virtual environment. Will install packages in user space."
    
    # Install packages in user space
    echo "Installing required Python packages..."
    pip3 install --user requests
    
    if [ $? -ne 0 ]; then
        echo "Failed to install packages with pip3. Trying with pip..."
        pip install --user requests
        
        if [ $? -ne 0 ]; then
            echo "Error: Failed to install required packages."
            echo "Please install manually with: pip3 install --user requests"
            exit 1
        fi
    fi
else
    # Activate virtual environment and install packages
    echo "Activating virtual environment..."
    source sk_env/bin/activate
    
    echo "Installing required Python packages..."
    pip install requests
    
    echo "Virtual environment created and activated."
    echo "To activate it in the future, run: source sk_env/bin/activate"
    
    # Create activation script
    echo "Creating activation script..."
    cat > activate_env.sh << 'EOL'
#!/bin/bash
source sk_env/bin/activate
echo "Virtual environment activated. You can now run:"
echo "python continuous_sk_finder.py"
echo "or"
echo "./run_sk_finder.sh"
EOL
    chmod +x activate_env.sh
fi

# Make run script executable
chmod +x run_sk_finder.sh

# Create logs directory
mkdir -p logs

echo
echo "======================================"
echo "  Setup Complete!"
echo "======================================"
echo
echo "To start the SK Finder:"
if [ -f "sk_env/bin/activate" ]; then
    echo "1. Activate the virtual environment:"
    echo "   source sk_env/bin/activate"
    echo "   or run: ./activate_env.sh"
fi
echo "2. Start the script:"
echo "   ./run_sk_finder.sh"
echo
echo "To run in background (will keep running after logout):"
echo "nohup ./run_sk_finder.sh > nohup.out 2>&1 &"
echo
echo "Check logs with:"
echo "tail -f logs/sk_finder.log"
echo
echo "Good luck!" 