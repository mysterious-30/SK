# Continuous SK Finder

A tool to continuously generate and check Stripe secret keys until a valid one is found.

## Setup on Linux VPS (without root access)

1. Upload these files to your VPS:
   - `continuous_sk_finder.py` - The main Python script
   - `run_sk_finder.sh` - The bash script to run continuously

2. Make the bash script executable:
   ```
   chmod +x run_sk_finder.sh
   ```

3. Install required Python packages (if not already installed):
   ```
   pip3 install --user requests
   ```

## Running the Script

### Method 1: Direct Python Execution (Basic)

Run the Python script directly:
```
python3 continuous_sk_finder.py
```

This will prompt you to enter a batch size and will run until it finds a live key or until you stop it with Ctrl+C.

### Method 2: Using the Shell Script (Recommended)

For continuous operation, especially on a VPS, use the shell script:
```
./run_sk_finder.sh
```

This method offers several advantages:
- Automatic restart if the script crashes
- Log rotation to prevent filling up disk space
- Error handling and status reporting

### Method 3: Running in Background (Keep running after logout)

To keep the script running even after you log out from your VPS:
```
nohup ./run_sk_finder.sh > nohup.out 2>&1 &
```

To check on the process later:
```
ps aux | grep sk_finder
```

To view live logs:
```
tail -f logs/sk_finder.log
```

## Output Files

- `sk.txt`: All generated keys
- `sklive.json`: Any valid keys that were found

## Notes for VPS Operation

1. Be mindful of your VPS resources. This script can run continuously and consume memory and CPU.

2. Stripe has rate limiting and IP blocking systems. Running too many requests may get your IP temporarily blocked.

3. Check the logs periodically to see if any valid keys were found:
   ```
   cat logs/sk_finder.log | grep "LIVE"
   ```

4. To stop the script running in the background:
   ```
   pkill -f "run_sk_finder.sh"
   pkill -f "continuous_sk_finder.py"
   ```

## Important Disclaimer

This tool is for educational purposes only. Attempting to access Stripe accounts without authorization is against Stripe's Terms of Service and may be illegal. Use responsibly and only on systems you own or have permission to use. 