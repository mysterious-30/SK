#!/bin/bash

# Script to run the SK finder continuously on a Linux VPS
# This script includes automatic log rotation and error handling

# Configuration
LOG_DIR="logs"
LOG_FILE="$LOG_DIR/sk_finder.log"
MAX_LOG_SIZE=10485760  # 10MB in bytes
MAX_BACKUP_LOGS=5
PYTHON_CMD="python3"  # Change to python if your system uses that instead

# Create logs directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Function to rotate logs
rotate_logs() {
    if [ -f "$LOG_FILE" ]; then
        if [ $(stat -c%s "$LOG_FILE") -gt $MAX_LOG_SIZE ]; then
            echo "Rotating logs..."
            # Remove oldest log if max backups reached
            if [ -f "${LOG_FILE}.${MAX_BACKUP_LOGS}" ]; then
                rm "${LOG_FILE}.${MAX_BACKUP_LOGS}"
            fi
            
            # Shift all backup logs
            for (( i=${MAX_BACKUP_LOGS}-1; i>=1; i-- )); do
                j=$((i+1))
                if [ -f "${LOG_FILE}.${i}" ]; then
                    mv "${LOG_FILE}.${i}" "${LOG_FILE}.${j}"
                fi
            done
            
            # Move current log to .1
            mv "$LOG_FILE" "${LOG_FILE}.1"
            
            # Create new log file
            touch "$LOG_FILE"
        fi
    fi
}

# Check if Python is installed
if ! command -v $PYTHON_CMD &> /dev/null; then
    echo "Error: Python 3 is not installed. Please install Python 3."
    exit 1
fi

# Check if requests module is installed
if ! $PYTHON_CMD -c "import requests" &> /dev/null; then
    echo "Installing required Python packages..."
    # Try installing with pip3 first (no root required)
    pip3 install --user requests
    
    # Check if installation was successful
    if ! $PYTHON_CMD -c "import requests" &> /dev/null; then
        echo "Error: Failed to install required packages. Please install them manually:"
        echo "pip3 install --user requests"
        exit 1
    fi
fi

# Check if our Python script exists
if [ ! -f "continuous_sk_finder.py" ]; then
    echo "Error: continuous_sk_finder.py not found in the current directory."
    exit 1
fi

# Function to run the script
run_script() {
    echo "Starting SK Finder at $(date)" | tee -a "$LOG_FILE"
    echo "=====================================" | tee -a "$LOG_FILE"
    
    # Run the Python script and redirect output to log file
    $PYTHON_CMD continuous_sk_finder.py 2>&1 | tee -a "$LOG_FILE"
    
    # Check exit status
    EXIT_CODE=$?
    if [ $EXIT_CODE -ne 0 ]; then
        echo "Script exited with error code $EXIT_CODE at $(date)" | tee -a "$LOG_FILE"
    else
        echo "Script completed successfully at $(date)" | tee -a "$LOG_FILE"
    fi
    
    echo "=====================================" | tee -a "$LOG_FILE"
}

# Main loop
echo "SK Finder started. Press Ctrl+C to stop."
while true; do
    # Rotate logs if needed
    rotate_logs
    
    # Run the script
    run_script
    
    # If the script exits, wait a bit before restarting
    echo "Restarting in 30 seconds... (Press Ctrl+C to stop)" | tee -a "$LOG_FILE"
    sleep 30
done 